# Follicular Variant Thyroid CA > 2025-02-24 11:03am
https://universe.roboflow.com/gopi-4gff9/follicular-variant-thyroid-ca-mmqha

Provided by a Roboflow user
License: Public Domain

