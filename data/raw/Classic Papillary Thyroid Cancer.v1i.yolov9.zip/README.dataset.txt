# Classic Papillary Thyroid Cancer > 2025-02-24 10:59am
https://universe.roboflow.com/gopi-4gff9/classic-papillary-thyroid-cancer-wo5lm

Provided by a Roboflow user
License: CC BY 4.0

